﻿namespace BRIT
{
    public class ObjectRepository
    {

        /// <summary>
        /// Gets or sets Keyword.
        /// </summary>
        public string? Keyword { get; set; }

        /// <summary>
        /// Gets or sets Keyword.
        /// </summary>
        public string? ExpectedTitle { get; set; }


        /// <summary>
        /// Gets or sets ExpectedCity.
        /// </summary>
        public string? ExpectedCity { get; set; }


        /// <summary>
        /// Gets or sets ExpectedAddress.
        /// </summary>
        public string? ExpectedAddress { get; set; }

        /// <summary>
        /// Gets or sets ExpectedContact.
        /// </summary>
        public string? ExpectedContact { get; set; }


    }
}
