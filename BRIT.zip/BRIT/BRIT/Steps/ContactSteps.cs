﻿using BRIT.Common;
using BRIT.Commons;
using BRIT.ComponentHelper;
using BRIT.PageRepository;
using NUnit.Framework;
using System;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace BRIT.Steps
{
    [Binding]
    public class ContactSteps
    {
        private readonly ScenarioContext scenarioContext;
        public ContactSteps(ScenarioContext scenarioContext)
        {
            this.scenarioContext = scenarioContext;
        }

        [When(@"User navigates to the contact page using the menus")]
        public void WhenUserNavigatesToTheContactPageUsingTheMenus()
        {
            Navigate.GetBRITHomePageWebElement.ClickMenu();
            Utilities.driver?.Navigate().GoToUrl("https://www.britinsurance.com/contact");
            GenericHelper.

        }

        [When(@"Extract the Bermuda office address from the Bermuda office section")]
        public void WhenExtractTheBermudaOfficeAddressFromTheBermudaOfficeSection()
        {
            string? actualCity = Navigate.GetBRITHomePageWebElement.GetBermudaOfficeCity();
            string? actualAddress = Navigate.GetBRITHomePageWebElement.GetBermudaOfficeAddress();
            string? actualContact = Navigate.GetBRITHomePageWebElement.GetBermudaOfficeContact();

            this.scenarioContext["ActualCity"] = actualCity;
            this.scenarioContext["ActualAddress"] = actualAddress;
            this.scenarioContext["ActualContact"] = actualContact;

        }

        [Then(@"Validate the Bermuda office address which should contains expected address")]
        public void ThenValidateTheBermudaOfficeAddressWhichShouldContainsExpectedAddress(Table table)
        {
            var officeAddress = table.CreateSet<ObjectRepository>();
            foreach (ObjectRepository addressItems in officeAddress)
            {
                if (!string.IsNullOrEmpty(addressItems.ExpectedCity) && !string.IsNullOrEmpty(addressItems.ExpectedAddress) && !string.IsNullOrEmpty(addressItems.ExpectedContact))
                {
                    string expectedCity = addressItems.ExpectedCity;
                    string expectedAddress = addressItems.ExpectedAddress;
                    string expectedContact = addressItems.ExpectedContact;

                    var actualCity = this.scenarioContext["ActualCity"];
                    var actualAddress = this.scenarioContext["ActualAddress"];
                    var actualContact = this.scenarioContext["ActualContact"];

                    Assert.IsTrue(actualCity.Equals(expectedCity.Trim()), "Assert Failed: As City name is not correct !");
                    Assert.IsTrue(actualAddress.Equals(expectedAddress.Trim()), "Assert Failed: As Address is not correct !");
                    Assert.IsTrue(actualContact.Equals(expectedContact.Trim()), "Assert Failed: As Contact is not correct !");
                }
            }
        }

    }
}

