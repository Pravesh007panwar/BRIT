﻿using BRIT.Common;
using BRIT.ComponentHelper;
using BRIT.PageRepository;
using NUnit.Framework;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace BRIT.Steps
{
    [Binding]
    public class SearchSteps
    {
        [Given(@"User is at the Home Page")]
        public void GivenUserIsAtTheHomePage()
        {
            Navigate.GetBRITHomePageWebElement.WaitForTitle();
            Assert.IsTrue(Utilities.driver?.Title.Equals("Brit Insurance"), "Assert failed!: User is not at the Home Page");
            Navigate.GetBRITHomePageWebElement.ClickAllowCookies();

        }

        [When(@"User clicks on search icon in the search bar top right")]
        public void WhenUserClicksOnSearchIconInTheSearchBarTopRight()
        {
            Thread.Sleep(2000);
            Navigate.GetBRITHomePageWebElement.ClickSearchIcon();
        }

        [When(@"Enters the Keyword in the search bar and click on search icon")]
        public void WhenEntersTheKeywordInTheSearchBarAndClickOnSearchIcon(Table table)
        {
            var searchkeyword = table.CreateSet<ObjectRepository>();
            foreach (ObjectRepository searchItem in searchkeyword)
            {
                if (!string.IsNullOrEmpty(searchItem.Keyword))
                {
                    Navigate.GetBRITHomePageWebElement.EnterSearchKeyword(searchItem.Keyword);
                    Navigate.GetBRITHomePageWebElement.ClickSearchIcon();
                }
            }
        }


        [Then(@"Assert the number of search results which should be (.*) with ExpectedTitle")]
        public void ThenAssertTheNumberOfSearchResultsWhichShouldBeWithExpectedTitle(int resultNumber, Table table)
        {
            List<dynamic> expectedresultItems = new List<dynamic>();
            var searchResult = table.CreateSet<ObjectRepository>();
            foreach (ObjectRepository resultItems in searchResult)
            {
                if (!string.IsNullOrEmpty(resultItems.ExpectedTitle))
                {
                    expectedresultItems.Add(resultItems.ExpectedTitle);
                }
            }

            var searchedResultItems = Navigate.GetBRITHomePageWebElement.SearchedResultsItems();

            Assert.IsTrue(searchedResultItems?.Count.Equals(resultNumber), "Assert failed: As search result count didn't match!");

            for (int i = 0; i < searchedResultItems?.Count; i++)
            {
                Assert.IsTrue(searchedResultItems[i].Trim().Equals(expectedresultItems[i]), "Assert failed: As SearchResult items title didn't match !");
                Console.WriteLine("Expected Search Results With Titles:" + searchedResultItems[i]);
            }
        }
    }
}
