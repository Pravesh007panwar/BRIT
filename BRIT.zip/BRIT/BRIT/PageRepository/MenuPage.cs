﻿using BRIT.Common;
using BRIT.ComponentHelper;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BRIT.PageRepository
{
    public class MenuPage
    {

        private readonly IWebDriver driver;
        private readonly By contactLocator = By.LinkText("/contact");

        /// <summary>
        /// Initializes a new instance of the <see cref="DateTimePage"/> class.
        /// Construtor for calling the Driver Instance.
        /// </summary>
        /// <param name="driver"> WebDriver Instance.</param>
        public MenuPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void ClickContact()
        {
            IWebElement? ele = Utilities.driver?.FindElement(this.contactLocator);
            GenericHelper.ScrollToElementAndClick(Utilities.driver, ele);
        }

    }
}
