﻿// <copyright file="Navigate.cs" company="GnD">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace BRIT.PageRepository
{
    using BRIT.Common;
    using OpenQA.Selenium.Support.Events;

    /// <summary>
    /// Navigate.
    /// </summary>
    public static class Navigate
    {
        /// <summary>
        /// Gets GetErrorPopUpPage.
        /// </summary> 
        public static BRITHomePage GetBRITHomePageWebElement
        {
            get
            {
                var getBRITHomePageWebElement = new BRITHomePage(Utilities.driver);
                return getBRITHomePageWebElement;
            }
        }

        /// <summary>
        /// Gets GetErrorPopUpPage.
        /// </summary> 
        public static MenuPage GetMenuPageWebElement
        {
            get
            {
                var getMenuPage = new MenuPage(Utilities.driver);
                return getMenuPage;
            }
        }

    }
}