﻿using BRIT.Common;
using BRIT.Commons;
using BRIT.ComponentHelper;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;

namespace BRIT.PageRepository
{
    public class BRITHomePage
    {

        private readonly IWebDriver driver;
        private readonly By serachIconLocator = By.XPath("//button[@type='button']");
        private readonly By homePageLogotext = By.CssSelector("div.component--header__logo");
        private readonly By searchbarLocator = By.XPath("//input[@type='search']");
        private readonly By searchResultsLocator = By.CssSelector("a.s-results__tag");
        private readonly By allowCookiesLocator = By.XPath("//*[@id='CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection']");
        private readonly By menuLocator = By.CssSelector("button.header--toggle");
        private readonly By addressCityLocator = By.XPath("//*[@id='bermudaoffice']//p");
        private readonly By bermudaOfficeAddressLocator = By.XPath("//*[@id='bermudaoffice']//address");
        private readonly By bermudaOfficeLocationContactlocator = By.XPath("//*[@id='bermudaoffice']//a");

        /// <summary>
        /// Initializes a new instance of the <see cref="DateTimePage"/> class.
        /// Construtor for calling the Driver Instance.
        /// </summary>
        /// <param name="driver"> WebDriver Instance.</param>
        public BRITHomePage(IWebDriver driver)
        {
            this.driver = driver;
        }

        /// <summary>
        /// This method is used to click on search Icon at BRIT home page.
        /// </summary>
        public void ClickSearchIcon()
        {
            GenericHelper.WaitForElementToBeVisible(this.homePageLogotext);
            GenericHelper.WebElementClick(serachIconLocator);
        }

        /// <summary>
        /// This method is used to click on search Icon at BRIT home page.
        /// </summary>
        public void ClickAllowCookies()
        {
            GenericHelper.WebElementClick(allowCookiesLocator);
        }

        public void EnterSearchKeyword(string searchitem)
        {
            GenericHelper.Sendkeys(this.searchbarLocator, searchitem);
        }

        public List<string>? SearchedResultsItems()
        {
            var searchREsultItems = Utilities.driver?.FindElements(this.searchResultsLocator).GetTextValuesFromEachCollectionItem();
            return searchREsultItems;
        }

        public void WaitForTitle()
        {
            WebDriverWait wait = new WebDriverWait(Utilities.driver, TimeSpan.FromSeconds(70));
            wait.Until(ExpectedConditions.TitleIs("Brit Insurance"));
        }

        public void ClickMenu()
        {
            GenericHelper.WebElementClick(this.menuLocator);
        }

        public string? GetBermudaOfficeCity()
        {
            string? eletext = GenericHelper.GetelementText(this.addressCityLocator);
            return eletext;
        }

        public string? GetBermudaOfficeAddress()
        {
            string? eletext = GenericHelper.GetelementText(this.bermudaOfficeAddressLocator);
            var eletextnew = eletext?.Replace("\r\n", "");
            return eletextnew;
        }

        public string? GetBermudaOfficeContact()
        {
            string? eletext = GenericHelper.GetelementText(this.bermudaOfficeLocationContactlocator);
            return eletext;
        }

    }
}
