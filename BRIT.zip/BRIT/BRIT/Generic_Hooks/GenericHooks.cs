﻿using BRIT.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace BRIT.Generic_Hooks
{
    [Binding]
    public sealed class GenericHooks
    {
        [BeforeScenario]
        public static void BeforeScenario()
        {
            Utilities.LaunchBrowser();
            Utilities.NavigateToUrl();
        }

        [AfterScenario]
        public static void AfterScenario()
        {
            Utilities.Teardown();
        }
    }
}
