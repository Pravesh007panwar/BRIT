﻿// <copyright file="Utilities.cs" company="GnD">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace BRIT.Common
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Reflection;
    using System.Threading;
    using Microsoft.Extensions.Configuration;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Chrome;
    using OpenQA.Selenium.Firefox;
    using OpenQA.Selenium.IE;
    using OpenQA.Selenium.Support.UI;
    using SeleniumExtras.WaitHelpers;
    using WebDriverManager.DriverConfigs.Impl;


    /// <summary>
    /// This class contains all utilities.
    /// </summary>
    public class Utilities
    {
        public static IWebDriver? driver;
        public static readonly IConfigurationRoot Config = new ConfigurationBuilder().AddJsonFile("AppConfig.json").Build();
        private static readonly string? Browser = Config["Browser"];
        private static bool acceptNextAlert = true;

        /// <summary>
        /// This is a generic method to launch browser.
        /// </summary>
        public static void LaunchBrowser()
        {
            switch (Browser?.ToLower())
            {
                case "ie":

                    InternetExplorerOptions options_IE = new InternetExplorerOptions();

                    options_IE.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                    options_IE.IgnoreZoomLevel = false;
                    driver = new InternetExplorerDriver(options_IE);

                    driver.Manage().Window.Maximize();
                    driver.Manage().Timeouts().ImplicitWait.Add(TimeSpan.FromSeconds(2));

                    break;

                case "chrome":

                    ChromeOptions option = new ChromeOptions();
                    option.AddArgument("start-maximized");
                    option.AddArgument("--no-sandbox");
                    option.AddExcludedArgument("--enable-automation");
                    new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
                    option.AddUserProfilePreference("credentials_enable_service", false);
                    option.AddUserProfilePreference("profile.password_manager_enabled", false);
                    driver = new ChromeDriver(option);
                    driver.Manage().Timeouts().ImplicitWait.Add(TimeSpan.FromSeconds(60));
                    driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
                    driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
                    break;

                case "firefox":
                    driver = new FirefoxDriver();
                    driver.Manage().Window.Maximize();
                    driver.Manage().Timeouts().ImplicitWait.Add(TimeSpan.FromSeconds(20));

                    break;

                default:

                    InternetExplorerOptions options_IEDefault = new InternetExplorerOptions();
                    options_IEDefault.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                    options_IEDefault.IgnoreZoomLevel = true;
                    driver = new InternetExplorerDriver(options_IEDefault);
                    driver.Manage().Window.Maximize();

                    break;
            }
        }

        /// <summary>
        /// This method is used to navigate the url on browser.
        /// </summary>
        public static void NavigateToUrl()
        {
            if (driver != null)
            {
                driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                driver.Navigate().GoToUrl(Config["URL"]);
            }
        }


        /// <summary>
        /// This method is used to close the browser(driver).
        /// </summary>
        public static void Teardown()
        {
            try
            {
                if (driver != null)
                {
                    driver?.Close();
                    driver?.Quit();
                }
            }
            catch (Exception)
            {
            }
        }


        /// <summary>
        ///  This method is used to close the Alert/pop-up  by clicking  Yes/Accept button from Alet/Pop-up
        /// </summary>

        public static void AcceptAndCloseAlert()
        {
            try
            {
                IAlert? alert = driver?.SwitchTo().Alert();
                if (acceptNextAlert)
                {
                    alert?.Accept();
                }
                else
                {
                    alert?.Dismiss();
                }
            }
            finally
            {
                acceptNextAlert = true;
            }
        }

        /// <summary>
        /// This method is used to choose the dropdown by its identifier
        /// </summary>
        /// <param name="element">webelement.</param>
        /// <returns>It returns the dropdown controler of spefied identifier which can be further used for selection of  items using various options.</returns>
        public static SelectElement Dropdown(IWebElement element)
        {
            SelectElement select = new SelectElement(element);

            return select;
        }

        /// <summary>
        /// This method is use to select drop down element.
        /// </summary>
        /// <param name="selectDrpDwnLocator">element need to select.</param>
        /// <returns>it will return the selected element.</returns>
        public static SelectElement Dropdown(By selectDrpDwnLocator)
        {
            SelectElement select = new SelectElement(driver?.FindElement(selectDrpDwnLocator));

            return select;
        }


        /// <summary>
        /// Get Collection.
        /// </summary>
        /// <param name="locator">locator name.</param>
        /// <returns>collection.</returns>
        public static List<IWebElement> GetCollection(By locator)
        {
            List<IWebElement>? collection = driver?.FindElements(locator).ToList();
            return collection;
        }

        /// <summary>
        /// This method is used to get the similar elements to the IWebElement list
        /// </summary>
        /// <param name="locator">web element locator.</param>
        /// <returns>List.</returns>
        public static List<IWebElement> GetCollectionToList(By locator)
        {
            List<IWebElement>? webElementList = driver?.FindElements(locator).ToList();
            return webElementList;
        }

        /// <summary>
        /// SelectFromListDropDown.
        /// </summary>
        /// <param name="iWebElementsCollection">IWebElementsCollection.</param>
        /// <param name="itemName">itemName.</param>
        public static void SelectFromListDropDown(IList<IWebElement> iWebElementsCollection, string itemName)
        {
            if (itemName.Length >= 1)
            {
                foreach (IWebElement item in iWebElementsCollection)
                {
                    if (item.Text == itemName)
                    {
                        Thread.Sleep(1500);
                        item.Click();
                        break;
                    }
                }
            }
        }


    }
}
