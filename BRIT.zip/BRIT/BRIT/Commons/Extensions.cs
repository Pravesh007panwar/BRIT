﻿using BRIT.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BRIT.Commons
{
    public static class Extensions
    {
        /// <summary>
        /// Get a list of text values of each item in collection.
        /// </summary>
        /// <param name="collection">collection.</param>
        /// <returns>collectionTextList.</returns>
        public static List<string> GetTextValuesFromEachCollectionItem(this IList<IWebElement> collection)
        {
            List<string> collectionTextList = new List<string>();

            foreach (IWebElement item in collection)
            {
                collectionTextList.Add(item.Text);
            }

            return collectionTextList;
        }

        /// <summary>
        /// Used to Scroll to the Iwebelement using action class.
        /// </summary>
        /// <param name="element">element.</param>
        public static void ScrollToElementAndClickOnIt(this IWebElement element)
        {
            try
            {
                ScrollToElement(element);
                element.Click();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Used to Scroll to the Iwebelement using action class.
        /// </summary>
        /// <param name="element">element.</param>
        public static void ScrollToElement(this IWebElement element)
        {
            Actions act = new Actions(Utilities.driver);
            act.MoveToElement(element).Perform();
        }

        /// <summary>
        /// It is used to execute any custome JavaScript/jquery.
        /// </summary>
        /// <param name="driver">ExecuteJs.</param>
        /// <param name="script">script.</param>
        /// <returns>javascript execute.</returns>
        public static object ExecuteJs(this IWebDriver driver, string script)
        {
            return ((IJavaScriptExecutor)driver).ExecuteScript(script);
        }
    }
}
