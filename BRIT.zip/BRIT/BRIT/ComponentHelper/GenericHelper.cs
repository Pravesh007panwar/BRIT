﻿// <copyright file="GenericHelper.cs" company="GnD">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace BRIT.ComponentHelper
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Linq;
    using System.Threading;
    using BRIT.Common;
    using NUnit.Framework;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Interactions;
    using OpenQA.Selenium.Support.Extensions;
    using OpenQA.Selenium.Support.UI;
    using SeleniumExtras.WaitHelpers;
    using TechTalk.SpecFlow;

    /// <summary>
    /// GenericHelper class.
    /// </summary>
    public static class GenericHelper
    {
        /// <summary>
        /// Sendkeys.
        /// </summary>
        /// <param name="locator">Webele.</param>
        /// <param name="key">send value.</param>
        public static void Sendkeys(By locator, string key)
        {
            IWebElement? ele = Utilities.driver?.FindElement(locator);
            WebDriverWait wait = new WebDriverWait(Utilities.driver, TimeSpan.FromSeconds(70));
            wait.Until(ExpectedConditions.ElementToBeClickable(ele));
            wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(locator));
            ele?.Clear();
            ele?.SendKeys(key);
        }

        /// <summary>
        /// This is a genric method to click on web element.
        /// </summary>
        /// <param name="locator">WebElement locator.</param>
        public static void WebElementClick(By locator)
        {
            IWebElement? ele = Utilities.driver?.FindElement(locator);
            WebDriverWait wait = new WebDriverWait(Utilities.driver, TimeSpan.FromSeconds(70));
            wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(locator));
            wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(locator));
            wait.Until(ExpectedConditions.ElementToBeClickable(ele));
            ele?.Click();
        }

        /// <summary>
        /// Used to Scroll to the Iwebelement.
        /// </summary>
        /// <param name="driver">driver.</param>
        /// <param name="element">element.</param>
        public static void ScrollToElementAndClick(this IWebDriver driver, IWebElement element)
        {
            if (element == null)
            {
                return;
            }

            var elemPosY = element.Location.Y;
            var elemPosX = element.Location.X;
            ((IJavaScriptExecutor)driver).ExecuteScript($"window.scroll({elemPosX}, {elemPosY});");
            Thread.Sleep(TimeSpan.FromSeconds(10));
            element.Click();
        }

        public static void WaitForElementToBeVisible(By locator)
        {
            WebDriverWait wait = new WebDriverWait(Utilities.driver, TimeSpan.FromSeconds(70));
            wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(locator));
        }

        /// <summary>
        /// GetelementText.
        /// </summary>
        /// <param name="locator">Element Locator.</param>
        /// <returns>Element text.</returns>
        public static string? GetelementText(By locator)
        {
            WebDriverWait wait = new WebDriverWait(Utilities.driver, TimeSpan.FromSeconds(70));
            wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(locator));
            wait.Until(ExpectedConditions.PresenceOfAllElementsLocatedBy(locator));
            IWebElement? ele = Utilities.driver?.FindElement(locator);
            return ele?.Text;
        }
    }
}